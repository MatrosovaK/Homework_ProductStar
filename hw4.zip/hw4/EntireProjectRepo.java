package com.roks.real_postgres.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EntireProjectRepo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<String> getTop10WalkingUsersFromDb() {
        String sql = """
                SELECT user_login
                FROM public.walks
                GROUP BY user_login
                ORDER BY COUNT(*) DESC
                LIMIT 10
                """;

        return jdbcTemplate.queryForList(sql, String.class);
    }
}